// extracting the index.html inline script to avoid CSP restrictions
// this works INSIDE the iframe context that runs AS A CHILD of the main page
// keep that in mind when sending messages!

var container = document.querySelector("#unity-container");
var canvas = document.querySelector("#unity-canvas");
var loadingBar = document.querySelector("#unity-loading-bar");
var progressBarFull = document.querySelector("#unity-progress-bar-full");
var warningBanner = document.querySelector("#unity-warning");

// Shows a temporary message banner/ribbon for a few seconds, or
// a permanent error message on top of the canvas if type=='error'.
// If type=='warning', a yellow highlight color is used.
// Modify or remove this function to customize the visually presented
// way that non-critical warnings and error messages are presented to the
// user.
function unityShowBanner(msg, type) {
    function updateBannerVisibility() {
        warningBanner.style.display = warningBanner.children.length ? 'block' : 'none';
    }
    var div = document.createElement('div');
    div.innerHTML = msg;
    warningBanner.appendChild(div);
    if (type == 'error') div.style = 'background: red; padding: 10px;';
    else {
        if (type == 'warning') div.style = 'background: yellow; padding: 10px;';
        setTimeout(function() {
            warningBanner.removeChild(div);
            updateBannerVisibility();
        }, 5000);
    }
    updateBannerVisibility();
}

var buildUrl = "Build";
var loaderUrl = buildUrl + "/MASpinner_v1.0.1rc.loader.js";
var config = {
    dataUrl: buildUrl + "/MASpinner_v1.0.1rc.data",
    frameworkUrl: buildUrl + "/MASpinner_v1.0.1rc.framework.js",
    codeUrl: buildUrl + "/MASpinner_v1.0.1rc.wasm",
    streamingAssetsUrl: "StreamingAssets",
    companyName: "DefaultCompany",
    productName: "MathAddictSpinner",
    productVersion: "0.1",
    showBanner: unityShowBanner,
};

// By default Unity keeps WebGL canvas render target size matched with
// the DOM size of the canvas element (scaled by window.devicePixelRatio)
// Set this to false if you want to decouple this synchronization from
// happening inside the engine, and you would instead like to size up
// the canvas DOM size and WebGL render target sizes yourself.
// config.matchWebGLToCanvasSize = false;

if (/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)) {
    // Mobile device style: fill the whole browser client area with the game canvas:

    var meta = document.createElement('meta');
    meta.name = 'viewport';
    meta.content = 'width=device-width, height=device-height, initial-scale=1.0, user-scalable=no, shrink-to-fit=yes';
    document.getElementsByTagName('head')[0].appendChild(meta);
    container.className = "unity-mobile";
    canvas.className = "unity-mobile";

    // To lower canvas resolution on mobile devices to gain some
    // performance, uncomment the following line:
    // config.devicePixelRatio = 1;


} else {
    // Desktop style: Render the game canvas in a window that can be maximized to fullscreen:

    canvas.style.width = "395px";
    canvas.style.height = "706px";
}

loadingBar.style.display = "block";

var script = document.createElement("script");
script.src = loaderUrl;
script.onload = () => {
    createUnityInstance(canvas, config, (progress) => {
        progressBarFull.style.width = 100 * progress + "%";

    }).then((unityInstance) => {
        window.unityInstance = unityInstance;
        loadingBar.style.display = "none";

        // notify content.js
        window.parent.postMessage({
            source: "UnityLoader",
            type: "unityReady"
        }, "*");

    }).catch((message) => {
        alert(message);
    });
};

// patch for audio errors (bad logs still spit out until first gesture)
document.addEventListener("click", () => {
    if (typeof UnityAudioContext !== "undefined" && UnityAudioContext.state === "suspended") {
        console.log("[MathAddict][UnityLoader][AudioClick] #\n#\n#\n#\nUHHHH whats going on here?")
        UnityAudioContext.resume();
    }
});

document.body.appendChild(script);
